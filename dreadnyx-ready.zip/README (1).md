# Telegram-WhatsApp Bot

Un bot intelligent compatible **Telegram** et **WhatsApp**, avec des fonctionnalités puissantes : IA, téléchargement YouTube, stickers, anti-liens, mentions globales, fun facts et bien plus.

## Fonctionnalités disponibles

### Commandes Telegram :

- `/ai` — Pose une question à l'IA (GPT-3.5)
- `/ytmp4` — Télécharge une vidéo YouTube en MP4
- `/sticker` — Transforme une image en sticker
- `/antilink` — Active la protection anti-liens dans le groupe
- `/tagall` — Mentionne tous les membres du groupe
- `/funfact` — Reçois une info amusante ou insolite
- `/menu` — Liste des commandes
- `/connect` — Génère un code de connexion (ex: `DREA-1234`)

### Commandes WhatsApp (avec Baileys) :

- `!ai` — Pose une question à l'IA
- `!funfact` — Reçois une info amusante
- `!menu` — Affiche la liste des commandes
- `!connect` — Génère un code (ex: `DREA-4321`)

---

## Installation

```bash
git clone https://github.com/ton-utilisateur/telegram-whatsapp-bot
cd telegram-whatsapp-bot
npm install
```

### Configuration

1. **Telegram Bot** : remplace `TON_TOKEN_TELEGRAM` dans `bot.js`
2. **OpenAI** : remplace `TA_CLE_OPENAI` dans `bot.js`
3. Pour WhatsApp : le QR code s’affichera automatiquement au lancement.

---

## Lancement

```bash
node bot.js
```

---

## Dépendances

- Baileys
- Telegraf
- OpenAI
- Axios
- YTDL-Core

---

## Auteur

Développé par **[TonNomOuPseudo]** – *Projet AKARAN & DREA Powered*