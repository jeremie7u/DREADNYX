# Akaran Anti-Ban Bot

Bot WhatsApp furtif basé sur Baileys, conçu pour éviter le bannissement, inclure un mode espion et crypter les logs.

## Fonctionnalités
- Anti-ban avec comportement humain
- Mode espion (cryptage des logs)
- Surveillance de mots interdits
- Réponses automatisées
- Protection contre le spam

## Installation

```bash
pkg install nodejs
git clone https://github.com/votre-utilisateur/Akaran-anti-ban-bot.git
cd Akaran-anti-ban-bot
npm install
npm start
```

## Configuration
- Ajoutez votre numéro WhatsApp dans le tableau `whitelist` dans `akaranshield.js`.
- Placez un fichier `spy_audio.ogg` dans le répertoire pour la commande `!audio`.

## Sécurité
Les logs sont encryptés automatiquement dans `spy_logs.enc`.

## Licence
MIT


## Commandes disponibles

### Système
- .ping — Vérifie si le bot est en ligne.
- .stats — Affiche les statistiques du bot.
- .restart — Redémarre le bot.

### Plugins
- .sticker — Convertit une image en sticker.
- .ytmp4 [lien] — Télécharge une vidéo YouTube.
- .ai [question] — Répond à une question via une IA.
- .menu — Affiche ce menu complet.

### Modération
- .ban [@user] — Bannit un utilisateur.
- .unban [@user] — Débannit un utilisateur.
- .promote — Se nommer automatiquement admin.
- .demoteowner — Éjecte l'admin principal.

### Utilitaires
- .bugandroid — Signaler un bug Android.
- .bugiphone — Signaler un bug iPhone.
- .encode — Encode un texte.
- .decode — Decode un texte.
- .ddos [ip] — Simule une attaque réseau (fictive).
