const menu = `⌜ AKARAN-7K BOT MENU ⌟

╭─❍ BUG ANDROID
│ • xdroid <num>
│ • xdroid2 <num>
│ • xinvisiblekill <num>
│ • xbrutality <num>
│ • xbrutality2 <num>
│
├─❍ BUG IPHONE
│ • xios <num>
│
├─❍ FORCE BUG
│ • forceblock <amount>
│ • forcegroup <groupid|amount>
│
├─❍ BUG OTHER
│ • callspam <num>
│ • xpairspam <num>
│ • xgroup <groupid>
│ • xgroupv2
│ • xgroupv3
│
├─❍ GROUP CONTROL
│ • promoteall
│ • demoteall
│ • kickall
│
├─❍ ENC/DEC
│ • enc (reply to doc)
│ • dec (reply to doc)
│
├─❍ DDOS
│ • ddos <url>
│ • checkhost <url>
│
├─❍ OWNER
│ • addprem <num>
│ • delprem <num>
│ • listprem
│
├─❍ RENTBOT
│ • reqpair <num>
│ • delpair <num>
│ • listpair
│ • checkprem
│
├─❍ UTILITY
│ • makecase (reply)
│ • listgc
│ • group-id
│ • rvo (view once)
│ • idch <link>
│ • hidetag
│ • totag
│ • sticker (reply media)
│ • steal (reply sticker)
│ • autoswview on/off
│ • deviceid
│ • getdevice
│ • ping
│ • play
│ • runtime
│ • backup
│
├─❍ DATABASE
│ • adddatabase
│ • deldatabase
│ • fetchdatabase
│
├─❍ SPAM
│ • spampair
│ • clearbugs
│
├─❍ HIJACK & BAN
│ • xpaircrash
│ • hijack-gc
│ • badboi-hijack
│ • user-report <num>
│ • text-ban
│ • text-ban2
│ • tempban
│ • group-ban
╰────────────`

module.exports = menu
