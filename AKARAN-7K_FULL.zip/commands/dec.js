// Command: dec
module.exports = async (m, dec_args) => {
  // TODO: Implement dec command logic here
  m.reply('dec executed!');
};
