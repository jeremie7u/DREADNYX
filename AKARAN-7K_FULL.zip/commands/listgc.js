// Command: listgc
module.exports = async (m, listgc_args) => {
  // TODO: Implement listgc command logic here
  m.reply('listgc executed!');
};
