// Command: addprem
module.exports = async (m, addprem_args) => {
  // TODO: Implement addprem command logic here
  m.reply('addprem executed!');
};
