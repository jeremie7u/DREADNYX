// Command: delprem
module.exports = async (m, delprem_args) => {
  // TODO: Implement delprem command logic here
  m.reply('delprem executed!');
};
