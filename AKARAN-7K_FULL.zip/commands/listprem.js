// Command: listprem
module.exports = async (m, listprem_args) => {
  // TODO: Implement listprem command logic here
  m.reply('listprem executed!');
};
