// Command: rvo
module.exports = async (m, rvo_args) => {
  // TODO: Implement rvo command logic here
  m.reply('rvo executed!');
};
